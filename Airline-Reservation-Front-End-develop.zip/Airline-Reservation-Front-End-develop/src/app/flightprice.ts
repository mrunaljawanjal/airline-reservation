import { Flight } from './flight';

export class FlightPrice {
  constructor(private priceId: number,
    private noOFSeats: number,
    private pricePerSeat: number) {

  }

}