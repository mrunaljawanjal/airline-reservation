export class LoginStatus {
    constructor(public userid: string,
        public name: string,
        public status: string)
        {}
}
