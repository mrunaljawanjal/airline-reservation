export class ConfirmBooking{
    constructor(public noOfSeats?: number,
        public email?: string,
        public flightNumber?: number,
        public dateOfBooking?: string,
        //public busTime?: string,
        public Tfare?: number
        ) { }

}