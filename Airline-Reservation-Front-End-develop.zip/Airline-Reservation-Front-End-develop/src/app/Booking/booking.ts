export class Booking {
    constructor(public NumberOfSeats?: number,
        public email?: string,
        public flightid?: number,
        public dateOfBooking?: string,
        public TotalPrice?: number
    ) { }

}