export class User {
  constructor(
      public fName?: string,
      public lName?: string,
      public email?: string,
      public password?: string,
      public dob?: string,
      public phoneNo?: number) {
  }
}