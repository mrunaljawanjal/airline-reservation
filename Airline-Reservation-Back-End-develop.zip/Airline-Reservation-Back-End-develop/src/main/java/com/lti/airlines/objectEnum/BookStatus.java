package com.lti.airlines.objectEnum;

public enum BookStatus {
	bookingSuccessful, bookingCancelled, passengerDetailsAdded
}
