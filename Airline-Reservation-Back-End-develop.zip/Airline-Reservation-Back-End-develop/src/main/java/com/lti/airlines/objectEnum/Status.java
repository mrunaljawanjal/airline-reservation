package com.lti.airlines.objectEnum;

public enum Status {
	TRUE, FALSE
}
